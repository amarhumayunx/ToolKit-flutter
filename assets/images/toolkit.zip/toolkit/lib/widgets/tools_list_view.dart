import 'package:flutter/material.dart';

import '../screens/compress_files_screen/compress_file_screen.dart';
import '../screens/ocr_screens/ocr_screen.dart';
import 'tool_item.dart';

class ToolsListView extends StatefulWidget {
  const ToolsListView({Key? key}) : super(key: key);

  @override
  State createState() => _ToolsListViewState();
}

class _ToolsListViewState extends State<ToolsListView> {
  final ScrollController _scrollController = ScrollController();
  int _currentPage = 0;
  final int _itemsPerPage = 4;

  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }

  @override
  void dispose() {
    _scrollController.removeListener(_onScroll);
    _scrollController.dispose();
    super.dispose();
  }

  void _onScroll() {
    if (_scrollController.hasClients) {
      final double offset = _scrollController.offset;
      final double maxScrollExtent = _scrollController.position.maxScrollExtent;

      // Calculate which page we're on based on scroll position
      final int page = (offset /
              maxScrollExtent *
              ((tools.length / _itemsPerPage).ceil() - 1))
          .round();

      if (page != _currentPage) {
        setState(() {
          _currentPage = page;
        });
      }
    }
  }

  // Navigate to the appropriate page based on tool name
  void _navigateToToolPage(BuildContext context, String toolName) {
    switch (toolName) {
      case 'OCR':
        Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => OcrScreen(),
        ));
        break;
      case 'Compress Files':
        Navigator.of(context).push(MaterialPageRoute(
          builder: (context) => CompressFileScreen(),
        ));
        break;
      case 'Merge Files':
        // Navigator.of(context).push(MaterialPageRoute(
        //   builder: (context) => const MergeFilesPage(),
        // ));
        break;
      case 'Edit File':
        // Navigator.of(context).push(MaterialPageRoute(
        //   builder: (context) => const EditFilePage(),
        // ));
        break;
      case 'Split File':
        // Navigator.of(context).push(MaterialPageRoute(
        //   builder: (context) => const SplitFilePage(),
        // ));
        break;
      case 'Rearrange File':
        // Navigator.of(context).push(MaterialPageRoute(
        //   builder: (context) => const RearrangeFilePage(),
        // ));
        break;
      case 'File Transfer':
        // Navigator.of(context).push(MaterialPageRoute(
        //   // builder: (context) => const FileTransferPage(),
        // )
        // );
        break;
      default:
        // Handle unknown tool
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Tool $toolName is not implemented yet')),
        );
    }
  }

  final List<Map<String, String>> tools = [
    {
      'icon': 'assets/icons/ocr_icon.svg',
      'name': 'OCR',
    },
    {
      'icon': 'assets/icons/compress_file_icon.svg',
      'name': 'Compress Files',
    },
    {
      'icon': 'assets/icons/merge_file_icon.svg',
      'name': 'Merge Files',
    },
    {
      'icon': 'assets/icons/edit_file_icon.svg',
      'name': 'Edit File',
    },
    {
      'icon': 'assets/icons/split_file_icon.svg',
      'name': 'Split File',
    },
    {
      'icon': 'assets/icons/rearrange_file_icon.svg',
      'name': 'Rearrange File',
    },
    {
      'icon': 'assets/icons/file_transfer_icon.svg',
      'name': 'File Transfer',
    },
  ];

  @override
  Widget build(BuildContext context) {
    final int pagesCount = (tools.length / _itemsPerPage).ceil();

    return Column(
      children: [
        // Fixed height container for the horizontal list
        SizedBox(
          height: 130,
          child: ListView.builder(
            controller: _scrollController,
            scrollDirection: Axis.horizontal,
            itemCount: tools.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ToolItem(
                  icon: tools[index]['icon'] as String,
                  name: tools[index]['name'] as String,
                  onTap: () {
                    // Navigate to the appropriate tool page
                    _navigateToToolPage(
                        context, tools[index]['name'] as String);
                  },
                ),
              );
            },
          ),
        ),

        // Pagination dots
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(
            pagesCount,
            (index) => Padding(
              padding: const EdgeInsets.symmetric(horizontal: 3),
              child: Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: _currentPage == index
                      ? Colors.black
                      : Colors.grey.withOpacity(0.6),
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
      ],
    );
  }
}

// You'll need to create these pages
class OcrPage extends StatelessWidget {
  const OcrPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('OCR')),
      body: const Center(child: Text('OCR Tool Page')),
    );
  }
}

class CompressFilesPage extends StatelessWidget {
  const CompressFilesPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Compress Files')),
      body: const Center(child: Text('Compress Files Tool Page')),
    );
  }
}

// Add similar class definitions for other tools:
// MergeFilesPage, EditFilePage, SplitFilePage, RearrangeFilePage, FileTransferPage
